import requests
from GetLoginToken import getlogintoken
import pymysql
from ConnectMysql import connectmysql
"""
#获取logintoken
#token = getlogintoken()

CoeDB = {
    "host":"192.168.9.147",
    "port": 3320,
    "user": "qamodify",
    "password": "ybvaulx7fh5497fh",
    "db": "ocean",
    "charset": "utf8"
}
connectmysql(CoeDB)"""

a = "zhu"
b = "zhangrui"
print("fujing is" + a + "\n" + "zhangrui is:" + b )
