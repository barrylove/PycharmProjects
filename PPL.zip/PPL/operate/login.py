from selenium import webdriver
import time

class Login():
    def login(self,driver, URL):
        #判断扫码登录成功
        while True:
            if driver.current_url == URL:
                print ("登录成功...")
                break
            else:
                print ("请扫码登录...")
                time.sleep(5)

