#coding=utf-8
from selenium import webdriver
from selenium.webdriver.support.ui import WebDriverWait
import time
import datetime
from selenium.common.exceptions import NoSuchElementException
import unittest
from operate.login import Login


class MainCase(unittest.TestCase):
    produrl = "https://oms-cloud.99bill.com/prod/html/pc-crm/index.html#/memo/memo-manage/memo-list"
    st2url = "https://oms-cloud.99bill.com/stage2/html/pc-crm/index.html#/memo/memo-manage/memo-list"

    def setUp(self):
        # 打开浏览器，到达主页面
        testurl = "https://oms-cloud.99bill.com/stage2/html/pc-crm/index.html#/login/"
        self.driver = webdriver.Chrome("D:\Python\chromedriver.exe")
        self.driver.get(testurl)
        loginer = Login()
        loginer.login(self.driver,self.st2url)

    def testcreatememo(self):
        #新建纪要
        self.driver.find_element_by_class_name("index__action-PWJfP").click()
        time.sleep(3)

        #点击选择选择日程
        self.driver.find_element_by_class_name("ant-btn-primary").click()
        time.sleep(3)

        #选择第一个日程
        self.driver.find_elements_by_link_text("选择")[0].click()
        time.sleep(3)

        #验证客户名称
        #验证商机阶段
        #验证拜访时间
        #验证会议位置
        #验证测试目的

        #添加客户联系人
        self.driver.find_element_by_class_name("ant-btn-sm").click()
        time.sleep(3)

        #选择第一页所有客户联系人,点击确定
        self.driver.find_element_by_class_name("ant-checkbox-input").click()
        time.sleep(3)
        self.driver.find_elements_by_tag_name("button")[-1].click()

        #添加快钱参会人

        #填写沟通内容
        self.driver.find_element_by_xpath\
            ("/html/body/div[1]/div/div/div/div/div[2]/div/div/div[2]/div[2]/div/div[5]/div[1]/textarea").clear()
        self.driver.find_element_by_xpath \
            ("/html/body/div[1]/div/div/div/div/div[2]/div/div/div[2]/div[2]/div/div[5]/div[1]/textarea").sendkeys()
    def tearDown(self):
        self.driver.quit()

if __name__ == "__main__":
    unittest.main(verbosity=2)