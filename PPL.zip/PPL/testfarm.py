
e=list(range(1,14))
print(e)